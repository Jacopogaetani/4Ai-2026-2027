public class Consulente extends Dipendente implements Premiabile{

    public Consulente(String nome, String matricola) {
        super(nome, matricola);
    }

    @Override
    public double calcolaStipendio() {
        return 0;
    }

    @Override
    public double calcolaPremio() {
        return 0;
    }
}
